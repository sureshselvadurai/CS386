Project Description:

     The final project will be a dynamic and interactive website that serves as my
      professional portfolio resembling the format and functionality of LinkedIn. It
      would be like a parody version of linkedin debiting my resume. A satirical
      approach emulating LinkedIn's complexity.

Name: Suresh Raja Selvadurai
Student ID: 20766418

Issues Faced - None
Resources - None
Help - None

