module.exports = {
  host: 'localhost',
  port: 3000,
  appName:'Suresh Raja Linkedin'
};
