module.exports = {
	mongo: {
		connectionString: "mongodb+srv://sureshrajaselvadurai:6KKGUUeKXa4cis29@cluster0.xhboqia.mongodb.net/?retryWrites=true&w=majority"
	}
};


